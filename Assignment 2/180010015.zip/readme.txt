Install the following utilities:
Attacker:
	hping3

Victim:
	snort
	htop

In order to simulate the attack, connect the victim and attacker to the same network, and expose the victim's ip to the attacker.
Run the commands given in the report to simulate the exact DDOS attack.
